
package Materia;

import javax.swing.*;
public class Material {
       
    public static void main (String[] args) {
   	MaterialEscrito uno=new MateriaEscrito();
        MaterialAudioVisual dos=new MaterialAudioVisual();
    String opcion;
     int n;
   	do{
   	opcion=JOptionPane.showInputDialog ("Bienvenido a Mediateca UDB \n 1.Material Escrito \n 2.Material AudioVisual \n3.Salir");
   	n=Integer.parseInt (opcion);
   	switch(n)
   	{
         case 1: uno.materialescrito();break;
   	 case 2:dos.materialaudio(); break;	
   	 case 3:System.exit (0);break;
   	}  		
   	}while(n!=4);}    

    private static class MateriaEscrito extends MaterialEscrito {

        public MateriaEscrito() {
        }
    }

    
    }

