/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javaeje1;
import java.util.Scanner;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Calendar;
/**
 *
 * @author kristian
 */
public class JavaEje1 {

   
    public static void main(String[] args) {
       Scanner sc = new Scanner(System.in);
       
        int a = 0;
        int year; // año
        int yearb; // año
        int month; // mes [1,...,12]
        int dayOfMonth; // día [1,...,31 ]
        String cadena;
        String s;
        String m = "m" ;
        String f = "f" ;
      
        System.out.println("Introduce un nombre: ");
        cadena = sc.nextLine();
         do {
            System.out.println("Introduce M o F para indicar su sexo: ");
        s = sc.nextLine();
          if (s.equalsIgnoreCase(m)){
                
            System.out.println( "Sexo maculino: ");  
            a= +4;
            }
          if (s.equalsIgnoreCase(f)){
                
            System.out.println( "Sexo femenino: ");
            a= +4;
            } else {
          System.out.println( "Ingrese M o F por favor ");
          }
        } while(a!=4);
        
        
    
System.out.println("Ingrese su dia de nacimiento dd");
dayOfMonth = sc.nextInt();
System.out.println("Ingrese su mes de nacimiento MM");
month = sc.nextInt();
System.out.println("Ingrese su anio de nacimiento yyyy");
year = sc.nextInt();
if (year <= 0 ) { //los años son mayores a 0
System.out.println("invalido");
}

Calendar calendar = Calendar.getInstance();
calendar.setLenient(false);
calendar.set(Calendar.YEAR, year);
calendar.set(Calendar.MONTH, month - 1); // [0,...,11]
calendar.set(Calendar.DAY_OF_MONTH, dayOfMonth);
Date date = calendar.getTime();
SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/YYYY");
System.out.println(sdf.format(date)); // dd/MM/yyyy
System.out.println("Fecha validada");





  String signo = "";
    switch (month) {
        case 1:
            if (dayOfMonth > 21) {
                signo = "ACUARIO";
            } else {
                signo = "CAPRICORNIO";
            }
            break;
        case 2:
                if (dayOfMonth > 19) {
                    signo = "PISCIS";
                } else {
                    signo = "ACUARIO";
                }
                break;
        case 3:
                if (dayOfMonth > 20) {
                    signo = "ARIES";
                } else {
                    signo = "PISCIS";
                }
                break;
        case 4:
                if (dayOfMonth > 20) {
                    signo = "TAURO";
                } else {
                    signo = "ARIES";
                }
                break;
        case 5:
                if (dayOfMonth > 21) {
                    signo = "GEMINIS";
                } else {
                    signo = "TAURO";
                }
                break;
        case 6:
                if (dayOfMonth > 20) {
                    signo = "CANCER";
                } else {
                    signo = "GEMINIS";
                }
                break;
        case 7:
                if (dayOfMonth > 22) {
                    signo = "LEO";
                } else {
                    signo = "CANCER";
                }
                break;
        case 8:
                if (dayOfMonth > 21) {
                    signo = "VIRGO";
                } else {
                    signo = "LEO";
                }
                break;
        case 9:
                if (dayOfMonth > 22) {
                    signo = "LIBRA";
                } else {
                    signo = "VIRGO";
                }
                break;
        case 10:
                if (dayOfMonth > 22) {
                    signo = "ESCORPION";
                } else {
                    signo = "LIBRA";
                }
                break;
        case 11:
                if (dayOfMonth > 21) {
                    signo = "SAGITARIO";
                } else {
                    signo = "ESCORPION";
                }
                break;
        case 12:
                if (dayOfMonth > 21) {
                    signo = "CAPRICORNIO";
                } else {
                    signo = "SAGITARIO";
                }
        break;
    }
            yearb = 2021 - year;

                if (yearb >= 30 && s.equalsIgnoreCase(m)){
                String middleName = cadena.split(" ")[1].trim();
            //System.out.println(middleName);
            System.out.println( "Buenos días Mr. " +middleName );
            System.out.println( "Su  signo zodiacal es: " +signo );
            
            //Si es divisible entre 4 y no es divisible entre 100 o es divisible entre 100 y 400.
                          if ((year % 4 == 0 && year % 100 != 0) || (year % 100 == 0 && year % 400 == 0)) {
                                System.out.println("El año " + year + " es bisiesto");
                         } else {
                               System.out.println("El año " + year + " no es bisiesto");
                                }
            }
                if (yearb <= 29 && s.equalsIgnoreCase(m)){
                  String middleName = cadena.split(" ")[0].trim();
            System.out.println( "Hola amigo " + middleName);
                   System.out.println( "Su  signo zodiacal es: " +signo );
                    if ((year % 4 == 0 && year % 100 != 0) || (year % 100 == 0 && year % 400 == 0)) {
                                System.out.println("El año " + year + " es bisiesto");
                         } else {
                               System.out.println("El año " + year + " no es bisiesto");
                                }
            }
                if (yearb >= 30 && s.equalsIgnoreCase(f)){
                 String middleName = cadena.split(" ")[1].trim();
            System.out.println( "Buenos días Ms. " +middleName);
                   System.out.println( "Su  signo zodiacal es: " +signo );
                    if ((year % 4 == 0 && year % 100 != 0) || (year % 100 == 0 && year % 400 == 0)) {
                                System.out.println("El año " + year + " es bisiesto");
                         } else {
                               System.out.println("El año " + year + " no es bisiesto");
                                }
            }
                if (yearb <= 29 && s.equalsIgnoreCase(f)){
                 String middleName = cadena.split(" ")[0].trim();
            System.out.println( "Hola amigo " + middleName);
                   System.out.println( "Su  signo zodiacal es: " +signo );
                    if ((year % 4 == 0 && year % 100 != 0) || (year % 100 == 0 && year % 400 == 0)) {
                                System.out.println("El año " + year + " es bisiesto");
                         } else {
                               System.out.println("El año " + year + " no es bisiesto");
                                }
            }
                
          
        
        
        
        
       
        
    }
    
}
